

import "./categoriesC.scss"
const CategoriesC =(props)=>{
  const styles= {color:"black"}
  return (
    




    <div className="catbox" key={props.id}>
        <img src={props.img}/>
        <h3>{props.title}</h3>
        <hr style ={styles}/>
        
        <a href="#" className="btn">See Products</a>
    </div>

    



    
    
  );
};

export default CategoriesC;
