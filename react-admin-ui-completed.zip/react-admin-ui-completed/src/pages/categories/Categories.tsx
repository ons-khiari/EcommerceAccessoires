
import catarray from "./catarray";
import "./categories.scss"
import CategoriesC from "../../components/categories/CategoriesC";
const Categories =()=>{
  const newarray=catarray.map(x=><CategoriesC
  title={x.title}
  img={x.img}/>)
    return (
    
<div className="bg">

<h1 className="heading">Categories</h1>

<div className="box-container" >
{newarray}
</div>
</div>


    
    
  );
};

export default Categories;
