export default [
    {
        id:"1",
        title:"Console" ,
        img: "https://store.sony.com.au/on/demandware.static/-/Sites-sony-master-catalog/default/dw1b537bbb/images/PLAYSTATION5W/PLAYSTATION5W.png",
    

    }
    ,
    {
        id:"2",
        title:"chemise" ,
        img:"https://www.pngmart.com/files/6/Dell-Laptop-PNG-Image.png"

    },
    {
        id:"3",
        title:"chemise" ,
        img: "http://images.samsung.com/is/image/samsung/uk-led-tv-hg40ed670ck-hg40ed670ckxxu-001-front",


    },
    {
        id:"4",
        title:"chemise" ,
        img: "https://raylo.imgix.net/iphone-14-blue.png"

    },  {
        id:"5",
        title:"chemise" ,
        img: "https://www.signify.com/b-dam/signify/en-aa/about/news/2020/20200903-movie-night-essentials-popcorn-ice-cream-and-the-new-philips-hue-play-gradient-lightstrip/packaging-lighstrip.png"

    },  {
        id:"6",
        title:"chemise" ,
        img: "https://www.smartworld.it/wp-content/uploads/2019/09/High_Resolution_PNG-MX-Master-3-LEFT-GRAPHITE.png"

    },
]